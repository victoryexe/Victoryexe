package fxapp;

import controllers.MapController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.Facade;

public class MainFXApplication extends Application {

    private Stage mainStage;
    private Scene mapScene;
    MapController controller;

    @Override
    public void start(Stage stage) throws Exception{
        stage.setTitle("Map and Persistence Demo");

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainFXApplication.class.getResource("../mapview.fxml"));
        BorderPane root = loader.load();

        mapScene = new Scene(root);
        controller = loader.getController();
        controller.setCallbacks(stage, this);

        stage.setScene(mapScene);


        mainStage = stage;

        //at this point the controller has made the window, setup the map and set it as the scene for the stage
        stage.show();

    }

    public static void main(String[] args) {
        System.setProperty("java.net.useSystemProxies", "true");
        launch(args);
    }

    /**
     * dummy method to simulate a callback from the map view
     */
    public void closeMapView() {
        Facade fc = Facade.getInstance();
        fc.addLocations();
        controller.mapInitialized();
        mainStage.setScene(mapScene);
    }

}
